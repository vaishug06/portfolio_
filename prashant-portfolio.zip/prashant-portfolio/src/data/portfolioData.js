export const profile = {
  name: "Prashant Ahire",
  title: "Assistant Professor",
  subtitle: "Electronics & Engineering",
  location: "Pune, Maharashtra, India",
  email: "prashanta@isquareit.edu.in",
  linkedin: "https://in.linkedin.com/in/prashant-ahire-75053171",
  website: "https://prashantahire.dev",
  tagline:
    "15+ years of teaching experience in Electronics and Engineering education. Passionate about mentoring students and advancing technical knowledge through innovative teaching methodologies.",
  about:
    "15+ years of teaching experience in Electronics and Engineering with 3+ years of research expertise. Currently an Assistant Professor at Hope Foundation's International Institute of Information Technology, Pune. Committed to bridging the gap between academic knowledge and industry requirements through practical, hands-on pedagogy.",
};

export const stats = [
  { value: "15+", label: "Years Teaching" },
  { value: "3+",  label: "Years Research" },
  { value: "6",   label: "Institutions" },
  { value: "4",   label: "Courses Offered" },
];

export const experience = [
  {
    role: "Assistant Professor",
    org: "Hope Foundation's IIIT",
    period: "Nov 2022 – Present",
    location: "Pune, Maharashtra",
    points: [
      "Teaching Electronics & Engineering to UG students",
      "Conducting research in emerging technologies",
      "Mentoring students in academic & professional development",
      "Developing innovative curriculum and lab experiments",
    ],
  },
  {
    role: "Assistant Professor",
    org: "A. P. Shah Institute of Technology",
    period: "Jun 2019 – Aug 2023",
    location: "Thane, Maharashtra",
    points: [
      "Taught Electronics & Engineering courses to UG students",
      "Supervised student projects and research work",
      "Contributed to academic program development",
      "Conducted laboratory sessions and practical training",
    ],
  },
  {
    role: "Assistant Professor",
    org: "SIES Graduate School Of Technology",
    period: "Jul 2018 – Aug 2023",
    location: "Nerul, Navi Mumbai",
    points: [
      "Delivered lectures on Electronics & Engineering subjects",
      "Guided student research and development projects",
      "Participated in curriculum enhancement initiatives",
      "Mentored students for competitive examinations",
    ],
  },
  {
    role: "Assistant Professor",
    org: "LTJSS Lokmanya Tilak College of Engineering",
    period: "Jan 2017 – May 2018",
    location: "Koparkhairane, Navi Mumbai",
    points: [
      "Taught Electronics and Mechanical Engineering subjects",
      "Developed practical laboratory experiments",
      "Assessed student performance and provided feedback",
      "Collaborated with industry for internship placements",
    ],
  },
  {
    role: "Assistant Professor",
    org: "MES Pillai's Institute of IT Engineering",
    period: "Jul 2012 – Oct 2015",
    location: "New Panvel",
    points: [
      "Taught Electronics & E&TC Engineering courses",
      "Supervised final year projects",
      "Conducted seminars and workshops",
      "Mentored students in technical skills development",
    ],
  },
  {
    role: "Assistant Professor",
    org: "JES A.C.Patil College of Engineering",
    period: "Aug 2003 – Jul 2012",
    location: "Kharghar, Navi Mumbai",
    points: [
      "Taught Electronics Engineering to UG students",
      "Developed course materials and laboratory manuals",
      "Guided student projects and research initiatives",
      "Participated in academic council and curriculum planning",
    ],
  },
];

export const skills = [
  {
    category: "Programming & Frameworks",
    items: ["Java", "JavaScript", "Web Development", "Data Analytics", "Programming"],
  },
  {
    category: "Architecture & Design",
    items: ["Object-Oriented Design", "Data Structures", "Algorithm Design", "Software Architecture"],
  },
  {
    category: "Data & Analytics",
    items: ["Data Analytics", "Data Visualization", "Statistical Analysis", "Analytics Platforms"],
  },
  {
    category: "Pedagogy",
    items: ["Curriculum Development", "Student Mentoring", "Academic Excellence", "Research Supervision"],
  },
];

export const courses = [
  {
    title: "Fundamentals of Java",
    desc: "Introduction to Java programming, object-oriented concepts, and basic application development",
    level: "Undergraduate",
    icon: "☕",
  },
  {
    title: "Advanced Java Programming",
    desc: "Advanced Java concepts including multithreading, collections, and enterprise application development",
    level: "Undergraduate",
    icon: "⚙️",
  },
  {
    title: "Data Analytics",
    desc: "Data analysis techniques, statistical methods, and data visualization for business intelligence",
    level: "Undergraduate",
    icon: "📊",
  },
  {
    title: "JavaScript",
    desc: "Web development with JavaScript, DOM manipulation, and modern JavaScript frameworks",
    level: "Undergraduate",
    icon: "🌐",
  },
];

export const philosophy = [
  {
    title: "Practical Learning",
    desc: "Emphasis on hands-on laboratory work and real-world applications to bridge theory and practice.",
    icon: "🔬",
  },
  {
    title: "Student Mentoring",
    desc: "Personalized guidance and mentoring to help students achieve their academic and professional goals.",
    icon: "🎯",
  },
  {
    title: "Innovation",
    desc: "Continuous curriculum development incorporating emerging technologies and industry trends.",
    icon: "💡",
  },
];

export const testimonials = [
  {
    name: "Rahul Sharma",
    role: "Software Engineer, TCS",
    text: "Prashant Sir's Java programming course was instrumental in my career. His practical approach and mentoring helped me secure my first job. Highly recommended!",
    initials: "RS",
  },
  {
    name: "Priya Patel",
    role: "Data Analyst, Accenture",
    text: "The Data Analytics course was comprehensive and industry-relevant. Sir's teaching methodology made complex concepts easy to understand.",
    initials: "PP",
  },
  {
    name: "Amit Kumar",
    role: "Full Stack Developer, Infosys",
    text: "Advanced Java Programming course deepened my understanding of OOP and multithreading. His support extended beyond the classroom.",
    initials: "AK",
  },
  {
    name: "Neha Gupta",
    role: "Frontend Developer, HCL",
    text: "JavaScript course was exceptional! Sir's real-world examples and hands-on projects made learning engaging and practical.",
    initials: "NG",
  },
  {
    name: "Sanjay Verma",
    role: "Colleague, HIIT Pune",
    text: "Working with Prashant as a colleague, I appreciate his dedication to curriculum innovation and student mentoring. A true educator.",
    initials: "SV",
  },
  {
    name: "Ananya Singh",
    role: "Graduate Student",
    text: "Sir's guidance during my research project was invaluable. His expertise and approachable nature made the learning journey smooth and rewarding.",
    initials: "AS",
  },
];

export const avatarColors = ["#1a3a5c", "#2d6a4f", "#7b2d8b", "#c05621", "#1a4a6b", "#4a1942"];

export const navItems = ["Home", "About", "Experience", "Courses", "Testimonials", "Contact"];

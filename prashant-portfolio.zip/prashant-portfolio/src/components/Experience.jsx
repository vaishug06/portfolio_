import { experience } from '../data/portfolioData';

export default function Experience({ sectionRef }) {
  return (
    <section
      ref={sectionRef}
      style={{ padding: '100px 5%', background: '#f2ede6' }}
    >
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        {/* Heading */}
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div className="section-label">Career</div>
          <h2 className="ff-display" style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700 }}>
            Work Experience
          </h2>
          <div className="gold-line gold-line--center" />
        </div>

        {/* Cards grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 24 }}>
          {experience.map((exp, i) => (
            <ExperienceCard key={i} exp={exp} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ExperienceCard({ exp }) {
  return (
    <div
      className="card-hover"
      style={{
        background: '#fff',
        border: '1px solid #ebe6df',
        borderTop: '3px solid #1a3a5c',
        padding: '32px 28px',
      }}
    >
      <div className="section-label" style={{ marginBottom: 8 }}>{exp.period}</div>
      <h3 className="ff-display" style={{ fontSize: 20, fontWeight: 600, marginBottom: 4 }}>{exp.role}</h3>
      <div className="ff-sans" style={{ fontSize: 14, fontWeight: 600, color: '#c8a96e', marginBottom: 4 }}>{exp.org}</div>
      <div className="ff-sans" style={{ fontSize: 13, color: '#999', marginBottom: 20 }}>📍 {exp.location}</div>
      <ul>
        {exp.points.map((p, j) => (
          <li key={j} className="ff-sans" style={{ display: 'flex', gap: 10, marginBottom: 8, fontSize: 14, color: '#4a4a4a', lineHeight: 1.6 }}>
            <span style={{ color: '#c8a96e', flexShrink: 0, marginTop: 2 }}>▸</span>
            {p}
          </li>
        ))}
      </ul>
    </div>
  );
}

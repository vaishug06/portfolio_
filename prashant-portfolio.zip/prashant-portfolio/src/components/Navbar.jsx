import { useState, useEffect, useRef } from 'react';
import { navItems } from '../data/portfolioData';

export default function Navbar({ sectionRefs }) {
  const [activeSection, setActiveSection] = useState('Home');
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
      const offsets = navItems.map((id) => {
        const el = sectionRefs.current[id];
        if (!el) return { id, top: Infinity };
        return { id, top: Math.abs(el.getBoundingClientRect().top - 80) };
      });
      const nearest = offsets.reduce((a, b) => (a.top < b.top ? a : b));
      setActiveSection(nearest.id);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [sectionRefs]);

  const scrollTo = (id) => {
    sectionRefs.current[id]?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'rgba(249,247,244,0.97)' : 'transparent',
      backdropFilter: scrolled ? 'blur(10px)' : 'none',
      borderBottom: scrolled ? '1px solid #ebe6df' : 'none',
      transition: 'all 0.35s',
      padding: '0 5%',
    }}>
      <div style={{
        maxWidth: 1100, margin: '0 auto',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        height: 68,
      }}>
        {/* Logo */}
        <button
          className="ff-display"
          onClick={() => scrollTo('Home')}
          style={{ fontSize: 22, fontWeight: 700, letterSpacing: '0.04em', color: '#1a3a5c', cursor: 'pointer', background: 'none', border: 'none' }}
        >
          PA
        </button>

        {/* Desktop nav */}
        <div className="hide-mobile" style={{ display: 'flex', gap: 36, alignItems: 'center' }}>
          {navItems.map((n) => (
            <NavLink key={n} label={n} active={activeSection === n} onClick={() => scrollTo(n)} />
          ))}
        </div>

        {/* Mobile toggle */}
        <button
          className="show-mobile btn-outline"
          style={{ padding: '6px 14px', fontSize: 12 }}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? '✕ Close' : '☰ Menu'}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: '#fff', borderTop: '1px solid #ebe6df', padding: '16px 5%' }}>
          {navItems.map((n) => (
            <div key={n} style={{ padding: '12px 0', borderBottom: '1px solid #f0ece6' }}>
              <NavLink label={n} active={activeSection === n} onClick={() => scrollTo(n)} />
            </div>
          ))}
        </div>
      )}
    </nav>
  );
}

function NavLink({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        cursor: 'pointer',
        fontFamily: "'Source Sans 3', sans-serif",
        fontSize: 13, fontWeight: 600,
        letterSpacing: '0.1em', textTransform: 'uppercase',
        padding: '6px 0',
        border: 'none', borderBottom: `2px solid ${active ? '#c8a96e' : 'transparent'}`,
        borderLeft: 'none', borderRight: 'none', borderTop: 'none',
        background: 'none',
        color: active ? '#1a1a1a' : '#4a4a4a',
        transition: 'color 0.2s, border-color 0.2s',
      }}
    >
      {label}
    </button>
  );
}

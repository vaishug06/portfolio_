import { testimonials, avatarColors } from '../data/portfolioData';

export default function Testimonials({ sectionRef }) {
  return (
    <section
      ref={sectionRef}
      style={{ padding: '100px 5%', background: '#f2ede6' }}
    >
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div className="section-label">Testimonials</div>
          <h2 className="ff-display" style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700 }}>
            What Students Say
          </h2>
          <div className="gold-line gold-line--center" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 24 }}>
          {testimonials.map((t, i) => (
            <TestimonialCard key={i} testimonial={t} color={avatarColors[i % avatarColors.length]} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialCard({ testimonial, color }) {
  return (
    <div
      className="card-hover"
      style={{
        background: '#fff',
        borderLeft: '3px solid #c8a96e',
        padding: '28px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Decorative quote mark */}
      <div style={{
        fontFamily: "'Playfair Display', serif",
        fontSize: 80, lineHeight: 1,
        color: 'rgba(200,169,110,0.12)',
        position: 'absolute', top: 8, right: 16,
        userSelect: 'none', pointerEvents: 'none',
      }}>
        "
      </div>

      <p
        className="ff-sans"
        style={{ fontSize: 15, lineHeight: 1.8, color: '#444', marginBottom: 24, fontStyle: 'italic' }}
      >
        "{testimonial.text}"
      </p>

      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 44, height: 44, borderRadius: '50%',
          background: color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff',
          fontFamily: "'Playfair Display', serif",
          fontSize: 15, fontWeight: 700, flexShrink: 0,
        }}>
          {testimonial.initials}
        </div>
        <div>
          <div className="ff-display" style={{ fontSize: 15, fontWeight: 600 }}>{testimonial.name}</div>
          <div className="ff-sans" style={{ fontSize: 12, color: '#999' }}>{testimonial.role}</div>
        </div>
      </div>
    </div>
  );
}

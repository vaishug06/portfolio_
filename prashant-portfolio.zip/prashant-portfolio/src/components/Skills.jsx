import { skills } from '../data/portfolioData';

export default function Skills() {
  return (
    <section style={{ padding: '100px 5%', background: '#1a3a5c' }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div className="section-label" style={{ color: '#c8a96e' }}>Expertise</div>
          <h2 className="ff-display" style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700, color: '#fff' }}>
            Skills &amp; Competencies
          </h2>
          <div className="gold-line gold-line--center" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 24 }}>
          {skills.map((s, i) => (
            <div
              key={i}
              style={{
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(200,169,110,0.25)',
                padding: '28px 24px',
              }}
            >
              <div className="ff-display" style={{ fontSize: 16, fontWeight: 600, color: '#c8a96e', marginBottom: 16 }}>
                {s.category}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {s.items.map((item, j) => (
                  <span
                    key={j}
                    className="ff-sans"
                    style={{
                      background: 'rgba(255,255,255,0.08)',
                      border: '1px solid rgba(255,255,255,0.12)',
                      color: '#c8d8ec',
                      padding: '4px 12px',
                      fontSize: 13,
                      borderRadius: 2,
                    }}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

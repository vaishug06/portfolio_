import { profile, stats } from '../data/portfolioData';

export default function Hero({ sectionRef, scrollTo }) {
  return (
    <section
      ref={sectionRef}
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        background: 'linear-gradient(135deg, #1a3a5c 0%, #0d2440 60%, #162f50 100%)',
        position: 'relative',
        overflow: 'hidden',
        padding: '100px 5% 60px',
      }}
    >
      {/* Decorative rings */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.05, pointerEvents: 'none' }}>
        {[...Array(8)].map((_, i) => (
          <div
            key={i}
            style={{
              position: 'absolute',
              border: '1px solid #c8a96e',
              borderRadius: '50%',
              width: 180 + i * 130,
              height: 180 + i * 130,
              top: '50%', left: '50%',
              transform: 'translate(-50%, -50%)',
            }}
          />
        ))}
      </div>

      {/* Grain overlay */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.025, pointerEvents: 'none',
        backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        backgroundSize: '256px 256px',
      }} />

      <div style={{
        maxWidth: 1100, margin: '0 auto', width: '100%',
        display: 'grid',
        gridTemplateColumns: 'clamp(280px, 60%, 660px) auto',
        gap: 60, alignItems: 'center',
      }}>
        {/* Left: text */}
        <div>
          <div className="section-label fade-up" style={{ color: '#c8a96e' }}>
            {profile.title} · {profile.subtitle}
          </div>
          <h1
            className="ff-display fade-up-2"
            style={{
              fontSize: 'clamp(42px, 6.5vw, 80px)',
              fontWeight: 900, color: '#fff',
              lineHeight: 1.05, marginBottom: 24,
            }}
          >
            {profile.name.split(' ')[0]}<br />{profile.name.split(' ')[1]}
          </h1>
          <div
            className="fade-up-3"
            style={{ width: 56, height: 3, background: 'linear-gradient(90deg,#c8a96e,#e8c98e)', marginBottom: 28 }}
          />
          <p
            className="ff-sans fade-up-3"
            style={{ fontSize: 17, lineHeight: 1.8, color: '#c8d8ec', maxWidth: 540, marginBottom: 40 }}
          >
            {profile.tagline}
          </p>
          <div className="fade-up-4" style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <button className="btn-primary btn-primary--gold" onClick={() => scrollTo('Courses')}>
              View Courses
            </button>
            <button className="btn-outline btn-outline--light" onClick={() => scrollTo('Contact')}>
              Get In Touch
            </button>
          </div>
        </div>

        {/* Right: stats */}
        <div className="hide-mobile" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          {stats.map((s, i) => (
            <div key={i} style={{ textAlign: 'right' }}>
              <div className="ff-display" style={{ fontSize: 44, fontWeight: 700, color: '#c8a96e', lineHeight: 1 }}>
                {s.value}
              </div>
              <div className="ff-sans" style={{ fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#7a99b8', marginTop: 4 }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

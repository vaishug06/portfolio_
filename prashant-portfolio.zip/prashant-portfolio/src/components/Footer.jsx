import { profile } from '../data/portfolioData';

export default function Footer() {
  return (
    <footer style={{ background: '#0a1929', padding: '36px 5%', textAlign: 'center' }}>
      <div className="ff-display" style={{ fontSize: 24, color: '#c8a96e', marginBottom: 8 }}>
        {profile.name}
      </div>
      <div className="ff-sans" style={{ fontSize: 13, color: '#4a6a8a', marginBottom: 20 }}>
        {profile.title} · Electronics &amp; Engineering · Pune, India
      </div>
      <div style={{ display: 'flex', gap: 28, justifyContent: 'center', marginBottom: 24 }}>
        <a href={profile.linkedin} target="_blank" rel="noreferrer" className="ff-sans" style={{ fontSize: 13, color: '#7a99b8' }}>
          LinkedIn
        </a>
        <a href={`mailto:${profile.email}`} className="ff-sans" style={{ fontSize: 13, color: '#7a99b8' }}>
          Email
        </a>
        <a href={`https://${profile.website}`} target="_blank" rel="noreferrer" className="ff-sans" style={{ fontSize: 13, color: '#7a99b8' }}>
          Website
        </a>
      </div>
      <div className="ff-sans" style={{ fontSize: 12, color: '#2a4a6a' }}>
        © {new Date().getFullYear()} {profile.name}. All rights reserved.
      </div>
    </footer>
  );
}

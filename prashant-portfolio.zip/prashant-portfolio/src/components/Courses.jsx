import { courses, philosophy } from '../data/portfolioData';

export default function Courses({ sectionRef }) {
  return (
    <section
      ref={sectionRef}
      style={{ padding: '100px 5%', background: '#f9f7f4' }}
    >
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        {/* Heading */}
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div className="section-label">Teaching</div>
          <h2 className="ff-display" style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700 }}>
            Courses I Teach
          </h2>
          <div className="gold-line gold-line--center" />
          <p className="ff-sans" style={{ fontSize: 16, color: '#777', marginTop: 20, maxWidth: 540, margin: '20px auto 0' }}>
            A comprehensive overview of courses covering Electronics, Engineering, and emerging technologies.
          </p>
        </div>

        {/* Course cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 24, marginBottom: 60 }}>
          {courses.map((c, i) => (
            <CourseCard key={i} course={c} />
          ))}
        </div>

        {/* Philosophy strip */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          background: '#1a3a5c',
        }}>
          {philosophy.map((p, i) => (
            <div
              key={i}
              style={{
                textAlign: 'center',
                padding: '48px 32px',
                borderRight: i < philosophy.length - 1 ? '1px solid rgba(255,255,255,0.08)' : 'none',
              }}
            >
              <div style={{ fontSize: 34, marginBottom: 14 }}>{p.icon}</div>
              <div className="ff-display" style={{ fontSize: 18, fontWeight: 600, color: '#c8a96e', marginBottom: 12 }}>{p.title}</div>
              <p className="ff-sans" style={{ fontSize: 14, color: '#c8d8ec', lineHeight: 1.75 }}>{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CourseCard({ course }) {
  return (
    <div
      className="card-hover"
      style={{
        background: '#fff',
        border: '1px solid #ebe6df',
        padding: '28px 24px',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Top accent bar */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: 3,
        background: 'linear-gradient(90deg, #1a3a5c, #2d5a8c)',
      }} />
      <div style={{ fontSize: 38, marginBottom: 16 }}>{course.icon}</div>
      <h3 className="ff-display" style={{ fontSize: 20, fontWeight: 600, marginBottom: 10 }}>{course.title}</h3>
      <p className="ff-sans" style={{ fontSize: 14, color: '#666', lineHeight: 1.75, marginBottom: 20 }}>{course.desc}</p>
      <span
        className="ff-sans"
        style={{
          background: '#f2ede6', color: '#1a3a5c',
          fontSize: 11, fontWeight: 700,
          letterSpacing: '0.1em', textTransform: 'uppercase',
          padding: '4px 12px', borderRadius: 2,
        }}
      >
        {course.level}
      </span>
    </div>
  );
}

import { profile, stats } from '../data/portfolioData';

export default function About({ sectionRef }) {
  return (
    <section
      ref={sectionRef}
      style={{ padding: '100px 5%', background: '#f9f7f4' }}
    >
      <div style={{
        maxWidth: 1100, margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: 80, alignItems: 'center',
      }}>
        {/* Left */}
        <div>
          <div className="section-label">About Me</div>
          <h2
            className="ff-display"
            style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700, lineHeight: 1.2, marginBottom: 24 }}
          >
            Educator.<br />Researcher.<br />Mentor.
          </h2>
          <div className="gold-line" />
          <p className="ff-sans" style={{ fontSize: 16, lineHeight: 1.9, color: '#4a4a4a', marginBottom: 28 }}>
            {profile.about}
          </p>
          <div className="ff-sans" style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 32 }}>
            <ContactChip icon="📍" text={profile.location} />
            <ContactChip icon="✉️" text={profile.email} href={`mailto:${profile.email}`} />
          </div>
          <a href={profile.linkedin} target="_blank" rel="noreferrer">
            <button className="btn-primary">LinkedIn Profile</button>
          </a>
        </div>

        {/* Right: stat cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {stats.map((s, i) => (
            <div
              key={i}
              className="card-hover"
              style={{
                background: i % 2 === 0 ? '#1a3a5c' : '#fff',
                border: '1px solid #ebe6df',
                padding: '36px 24px',
              }}
            >
              <div
                className="ff-display"
                style={{ fontSize: 52, fontWeight: 700, color: i % 2 === 0 ? '#c8a96e' : '#1a3a5c', marginBottom: 8, lineHeight: 1 }}
              >
                {s.value}
              </div>
              <div
                className="ff-sans"
                style={{ fontSize: 11, letterSpacing: '0.14em', textTransform: 'uppercase', color: i % 2 === 0 ? '#7a99b8' : '#999' }}
              >
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactChip({ icon, text, href }) {
  const inner = (
    <span style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#555', fontSize: 14 }}>
      <span style={{ color: '#c8a96e' }}>{icon}</span>
      <span style={href ? { color: '#1a3a5c', fontWeight: 600 } : {}}>{text}</span>
    </span>
  );
  return href ? <a href={href}>{inner}</a> : inner;
}

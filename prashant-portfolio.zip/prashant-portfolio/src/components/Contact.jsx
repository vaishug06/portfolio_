import { profile } from '../data/portfolioData';

const contactItems = [
  { icon: '✉️', label: 'Email',    getValue: (p) => p.email,           getHref: (p) => `mailto:${p.email}` },
  { icon: '💼', label: 'LinkedIn', getValue: () => 'prashant-ahire-75053171', getHref: (p) => p.linkedin },
  { icon: '🌐', label: 'Website',  getValue: (p) => p.website,          getHref: (p) => `https://${p.website}` },
  { icon: '📍', label: 'Location', getValue: (p) => p.location,         getHref: () => null },
];

export default function Contact({ sectionRef }) {
  return (
    <section
      ref={sectionRef}
      style={{ padding: '100px 5%', background: '#0d2440' }}
    >
      <div style={{ maxWidth: 700, margin: '0 auto', textAlign: 'center' }}>
        <div className="section-label" style={{ color: '#c8a96e' }}>Contact</div>
        <h2
          className="ff-display"
          style={{ fontSize: 'clamp(28px, 4vw, 44px)', fontWeight: 700, color: '#fff', marginBottom: 20 }}
        >
          Get In Touch
        </h2>
        <div className="gold-line" style={{ margin: '0 auto 28px' }} />
        <p
          className="ff-sans"
          style={{ fontSize: 16, color: '#7a99b8', lineHeight: 1.85, marginBottom: 48 }}
        >
          Whether you're a student seeking guidance, a colleague for collaboration, or an institution looking to connect — I'd love to hear from you.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 48 }}>
          {contactItems.map((c, i) => {
            const value = c.getValue(profile);
            const href  = c.getHref(profile);
            return (
              <div
                key={i}
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(200,169,110,0.2)',
                  padding: '28px 20px',
                }}
              >
                <div style={{ fontSize: 26, marginBottom: 10 }}>{c.icon}</div>
                <div
                  className="ff-sans"
                  style={{ fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: '#c8a96e', marginBottom: 8, fontWeight: 700 }}
                >
                  {c.label}
                </div>
                {href ? (
                  <a href={href} target="_blank" rel="noreferrer" className="ff-sans" style={{ fontSize: 14, color: '#c8d8ec', fontWeight: 500 }}>
                    {value}
                  </a>
                ) : (
                  <span className="ff-sans" style={{ fontSize: 14, color: '#c8d8ec' }}>{value}</span>
                )}
              </div>
            );
          })}
        </div>

        <a href={`mailto:${profile.email}`}>
          <button
            className="btn-primary btn-primary--gold"
            style={{ fontSize: 14, padding: '16px 48px', letterSpacing: '0.12em' }}
          >
            Send a Message
          </button>
        </a>
      </div>
    </section>
  );
}
